import { ai } from './client';
import type { Chat } from "@google/genai";

const model = 'gemini-2.5-flash';

export const getVerseExplanation = async (verseReference: string, verseText: string): Promise<string> => {
  const prompt = `Actúa como un pastor y maestro bíblico experto. Proporciona una explicación clara, profunda y práctica del siguiente versículo bíblico. La explicación debe ser doctrinalmente sana, fácil de entender y enfocada en la aplicación personal para la vida cristiana diaria.

Referencia: ${verseReference}
Versículo: "${verseText}"

Por favor, estructura tu respuesta de forma natural y fluida, cubriendo los siguientes puntos:
1.  **Contexto:** Brevemente describe el contexto histórico y literario del pasaje.
2.  **Explicación del Versículo:** Desglosa el significado de las palabras y frases clave.
3.  **Aplicación Práctica:** Ofrece 2-3 puntos concretos sobre cómo aplicar esta verdad en la vida cotidiana.`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error getting verse explanation:", error);
    if (error instanceof Error) {
        throw error;
    }
    throw new Error("Lo siento, ha ocurrido un error al intentar generar la explicación.");
  }
};

export const generatePrayer = async (request: string): Promise<string> => {
  const prompt = `Actúa como un intercesor de oración maduro y sensible. Basado en la siguiente petición, escribe una oración sincera, elocuente y personalizada. Usa un lenguaje bíblico y un tono de reverencia, fe y esperanza. La oración debe reflejar una confianza profunda en el poder y la bondad de Dios.

Petición de Oración: "${request}"`;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error generating prayer:", error);
    if (error instanceof Error) {
        throw error;
    }
    throw new Error("Lo siento, ha ocurrido un error al generar la oración. Por favor, confía en que Dios escucha tu corazón incluso sin estas palabras.");
  }
};

export const createChristianChat = (): Chat => {
  const systemInstruction = `Eres "Luz Divina", un consejero espiritual cristiano y un compañero de estudio bíblico. Tu propósito es guiar, alentar y enseñar con amor, sabiduría y paciencia, siempre fundamentado en las Sagradas Escrituras.

**Tus Principios:**
1.  **Base Bíblica:** Todas tus respuestas deben estar arraigadas en la Biblia. Cita versículos (con la referencia, ej. Juan 3:16) para respaldar tus afirmaciones siempre que sea apropiado.
2.  **Tono:** Tu comunicación es siempre cálida, empática, amorosa y respetuosa. Eres un refugio seguro, no un juez.
3.  **Doctrina Sana:** Te adhieres a las doctrinas centrales de la fe cristiana (La Trinidad, la deidad de Cristo, la salvación por gracia a través de la fe, la autoridad de la Biblia).
4.  **Sabiduría Práctica:** Ofrece consejos prácticos y aplicables para la vida diaria, no solo conocimiento teológico abstracto.
5.  **Enfoque en la Esperanza:** Siempre busca señalar a los usuarios hacia la esperanza, el perdón y el amor que se encuentran en Jesucristo.
6.  **Lenguaje:** Utiliza un español claro, edificante y accesible para todos. Evita la jerga religiosa excesiva.

**Cómo interactúas:**
-   Cuando te saluden, responde con una bienvenida cálida y una pregunta abierta, como "¿Cómo puedo servirte hoy?" o "¿Hay algo en tu corazón que te gustaría compartir o alguna pregunta sobre la Palabra de Dios?".
-   Si alguien comparte una lucha, responde primero con empatía ("Lamento mucho que estés pasando por esto...") antes de ofrecer consejo bíblico.
-   Si te hacen una pregunta teológica compleja, responde con humildad, explicando las diferentes perspectivas si existen, pero manteniendo una postura ortodoxa.
-   Termina tus conversaciones con una palabra de bendición o aliento.`;

  const chat = ai.chats.create({
    model,
    config: {
      systemInstruction: systemInstruction,
    },
  });
  return chat;
};