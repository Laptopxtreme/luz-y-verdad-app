import { GoogleGenAI } from "@google/genai";

const getAiClient = (): GoogleGenAI => {
    // This is the correct way to access environment variables in Vite.
    const apiKey = import.meta.env.VITE_API_KEY;

    if (!apiKey) {
        // This error will be thrown at runtime if the key is missing,
        // and can be caught by the components.
        throw new Error("La clave de API de Gemini no está configurada. Por favor, sigue las instrucciones del archivo leer.txt para configurarla.");
    }

    // Create a new instance every time to ensure the key is fresh,
    // although in practice it's a singleton for the app's lifecycle.
    return new GoogleGenAI({ apiKey });
};

// Initialize the client. If this fails, the error will be caught by the components.
export const ai = getAiClient();
